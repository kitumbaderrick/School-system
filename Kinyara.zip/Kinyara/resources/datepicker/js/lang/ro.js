var fdLocale = {
        months:[
                "Ianuarie",
                "Februarie",
                "Martie",
                "Aprilie",
                "Mai",
                "Iunie",
                "Iulie",
                "August",
                "Septembrie",
                "Octombrie",
                "Noiembrie",
                "Decembrie"
                ],
        fullDay:[
                "Luni",
                "Mar\u0163i",
                "Miercuri",
                "Joi",
                "Vineri",
                "S\u00e2mb\u00e3t\u00e3",
                "Duminic\u00e3"
                ],
        /* Only stipulate the dayAbbr should the first letter of the fullDay not suffice

        dayAbbr:[],
        */

        /* Only stipulate the firstDayOfWeek should the first day not be Monday

        firstDayOfWeek:0,
        */
        titles:[
                "Luna anterioar\u00e3",
                "Luna urm\u00e3toare",
                "Anul anterior",
                "Anul urm\u00e3tor"
                ]
};
